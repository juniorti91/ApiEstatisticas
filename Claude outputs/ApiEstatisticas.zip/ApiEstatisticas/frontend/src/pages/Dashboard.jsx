import { useCallback, useEffect, useMemo, useState } from "react";
import { ApiClient } from "../api/client";
import Header from "../components/Header";
import LiveMatchCard from "../components/LiveMatchCard";
import StatsComparisonPanel from "../components/StatsComparisonPanel";
import PerformanceComparisonTable from "../components/PerformanceComparisonTable";
import EvolutionChart from "../components/EvolutionChart";
import OddsMovementChart from "../components/OddsMovementChart";
import MainRecommendationCard from "../components/MainRecommendationCard";
import OtherRecommendations from "../components/OtherRecommendations";
import RecommendationHistoryTable from "../components/RecommendationHistoryTable";
import PerformanceFooter from "../components/PerformanceFooter";
import ManualEntryPanel from "../components/ManualEntryPanel";

const POLL_MS = 30000;

function formatClock(date) {
  return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export default function Dashboard({ onlyValueBets, selectedLeague }) {
  const [liveMatches, setLiveMatches] = useState([]);
  const [selectedMatchId, setSelectedMatchId] = useState(null);
  const [snapshots, setSnapshots] = useState([]);
  const [comparison, setComparison] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [oddsHistory, setOddsHistory] = useState([]);
  const [history, setHistory] = useState([]);
  const [performance, setPerformance] = useState(null);
  const [activeTab, setActiveTab] = useState("Visão Geral");
  const [lastUpdate, setLastUpdate] = useState(formatClock(new Date()));
  const [refreshing, setRefreshing] = useState(false);
  const [loadError, setLoadError] = useState("");

  const selectedMatch = useMemo(
    () => liveMatches.find((m) => m.id === selectedMatchId) || null,
    [liveMatches, selectedMatchId]
  );

  const loadLiveMatches = useCallback(async () => {
    const matches = await ApiClient.listLiveMatches();
    setLiveMatches(matches);
    if (matches.length > 0 && !matches.some((m) => m.id === selectedMatchId)) {
      setSelectedMatchId(matches[0].id);
    }
    if (matches.length === 0) setSelectedMatchId(null);
    return matches;
  }, [selectedMatchId]);

  const loadMatchDetail = useCallback(async (matchId) => {
    if (!matchId) {
      setSnapshots([]);
      setComparison(null);
      setRecommendations([]);
      setOddsHistory([]);
      return;
    }
    const [snaps, comp, recs] = await Promise.all([
      ApiClient.getSnapshots(matchId),
      ApiClient.getComparison(matchId).catch(() => null),
      ApiClient.listFixtureRecommendations(matchId).catch(() => []),
    ]);
    setSnapshots(snaps);
    setComparison(comp);
    setRecommendations(recs);

    const primary = recs.find((r) => r.is_primary) || recs[0];
    if (primary) {
      const hist = await ApiClient.getOddsHistory(primary.id).catch(() => []);
      setOddsHistory(hist);
    } else {
      setOddsHistory([]);
    }
  }, []);

  const loadAncillary = useCallback(async () => {
    const [hist, perf] = await Promise.all([
      ApiClient.getHistory(50).catch(() => []),
      ApiClient.getPerformance(30).catch(() => null),
    ]);
    setHistory(hist);
    setPerformance(perf);
  }, []);

  const loadAll = useCallback(async () => {
    try {
      setLoadError("");
      const matches = await loadLiveMatches();
      const targetId = matches.some((m) => m.id === selectedMatchId) ? selectedMatchId : matches[0]?.id ?? null;
      await Promise.all([loadMatchDetail(targetId), loadAncillary()]);
      setLastUpdate(formatClock(new Date()));
    } catch (err) {
      setLoadError("Não foi possível conectar ao backend. Verifique se o servidor FastAPI está rodando.");
    }
  }, [loadLiveMatches, loadMatchDetail, loadAncillary, selectedMatchId]);

  useEffect(() => {
    loadAll();
    const interval = setInterval(loadAll, POLL_MS);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadMatchDetail(selectedMatchId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMatchId]);

  async function handleRefresh() {
    setRefreshing(true);
    try {
      await ApiClient.collectNow();
      await loadAll();
    } catch {
      setLoadError("Falha ao disparar coleta manual - o backend pode estar offline.");
    } finally {
      setRefreshing(false);
    }
  }

  const latestSnapshot = snapshots.length ? snapshots[snapshots.length - 1] : null;
  const filteredMatches = liveMatches.filter(
    (m) => selectedLeague === "Todas" || m.league?.name === selectedLeague
  );
  const filteredRecommendations = onlyValueBets
    ? recommendations.filter((r) => r.is_value_bet)
    : recommendations;
  const primaryRec = filteredRecommendations.find((r) => r.is_primary) || filteredRecommendations[0];
  const otherRecs = filteredRecommendations.filter((r) => r.id !== primaryRec?.id);

  const matchForCard = selectedMatch
    ? {
        ...selectedMatch,
        possessionHome: latestSnapshot ? Math.round(latestSnapshot.possession_home) : 50,
        periodLabel: selectedMatch.status === "HT" ? "Intervalo" : selectedMatch.status === "2H" ? "2º TEMPO" : "1º TEMPO",
      }
    : null;

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      <Header lastUpdate={lastUpdate} onRefresh={handleRefresh} refreshing={refreshing} />

      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
        {loadError && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-lg px-4 py-3">
            {loadError}
          </div>
        )}

        {filteredMatches.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {filteredMatches.map((m) => (
              <button
                key={m.id}
                onClick={() => setSelectedMatchId(m.id)}
                className={`shrink-0 text-xs px-3 py-1.5 rounded-full border ${
                  m.id === selectedMatchId
                    ? "border-accent text-accent bg-accentdim"
                    : "border-border text-muted hover:text-slate-200"
                }`}
              >
                {m.home_team.name} x {m.away_team.name} ({m.elapsed_minutes}')
              </button>
            ))}
          </div>
        )}

        {selectedMatch ? (
          <div className="grid grid-cols-3 gap-5">
            <div className="col-span-2 space-y-5">
              <LiveMatchCard match={matchForCard} activeTab={activeTab} onTabChange={setActiveTab} />

              {activeTab === "Visão Geral" && (
                <div className="grid grid-cols-2 gap-5">
                  <StatsComparisonPanel
                    homeName={selectedMatch.home_team.name}
                    awayName={selectedMatch.away_team.name}
                    snapshot={latestSnapshot}
                  />
                  <PerformanceComparisonTable comparison={comparison} elapsedMinutes={selectedMatch.elapsed_minutes} />
                </div>
              )}

              {activeTab === "Comparativo" && (
                <PerformanceComparisonTable comparison={comparison} elapsedMinutes={selectedMatch.elapsed_minutes} />
              )}

              {activeTab === "Estatísticas" && (
                <StatsComparisonPanel
                  homeName={selectedMatch.home_team.name}
                  awayName={selectedMatch.away_team.name}
                  snapshot={latestSnapshot}
                />
              )}

              <div className="grid grid-cols-2 gap-5">
                <EvolutionChart
                  snapshots={snapshots}
                  homeName={selectedMatch.home_team.name}
                  awayName={selectedMatch.away_team.name}
                />
                <OddsMovementChart history={oddsHistory} marketLabel={primaryRec?.selection} />
              </div>

              <RecommendationHistoryTable rows={history} />
            </div>

            <div className="space-y-5">
              <MainRecommendationCard recommendation={primaryRec} />
              <OtherRecommendations recommendations={otherRecs} />
              <ManualEntryPanel
                selectedMatch={selectedMatch}
                onTracked={() => loadAll()}
                onSnapshotAdded={() => loadMatchDetail(selectedMatchId)}
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-5">
            <div className="col-span-2 bg-panel border border-border rounded-xl p-10 text-center">
              <p className="text-slate-200 font-medium mb-1">Nenhuma partida ao vivo monitorada no momento</p>
              <p className="text-sm text-muted">
                O sistema varre automaticamente as ligas configuradas a cada 2 minutos. Você também pode
                monitorar uma partida específica manualmente ao lado, informando o ID dela na API-Football.
              </p>
            </div>
            <ManualEntryPanel selectedMatch={null} onTracked={() => loadAll()} />
          </div>
        )}

        <PerformanceFooter performance={performance} />
      </div>
    </div>
  );
}
