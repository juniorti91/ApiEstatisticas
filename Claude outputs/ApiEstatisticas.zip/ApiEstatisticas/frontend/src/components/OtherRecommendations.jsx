import { Flag } from "lucide-react";

export default function OtherRecommendations({ recommendations }) {
  if (!recommendations || recommendations.length === 0) return null;

  return (
    <div className="bg-panel border border-border rounded-xl p-5">
      <div className="text-sm font-medium text-slate-200 mb-3">OUTRAS RECOMENDAÇÕES</div>
      <div className="space-y-2.5">
        {recommendations.map((r) => (
          <div key={r.id} className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-slate-300">
              <Flag size={13} className="text-muted" />
              {r.team_focus ? `${r.team_focus} - ${r.selection}` : r.selection}
            </span>
            <span className="flex items-center gap-2">
              <span className="text-slate-200">Odd: {r.odd.toFixed(2)}</span>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                  r.confidence_stars >= 4
                    ? "bg-accentdim text-accent"
                    : "bg-yellow-500/10 text-yellow-400"
                }`}
              >
                {r.confidence_stars >= 4 ? "ALTA" : "MÉDIA"}
              </span>
            </span>
          </div>
        ))}
      </div>
      <button className="w-full mt-4 bg-accentdim text-accent text-sm font-medium py-2 rounded-lg hover:brightness-110">
        VER TODAS RECOMENDAÇÕES
      </button>
    </div>
  );
}
