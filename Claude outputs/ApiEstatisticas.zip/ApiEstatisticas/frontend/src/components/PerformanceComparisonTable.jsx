import { ArrowUp, ArrowDown, Minus } from "lucide-react";

function TrendIcon({ trend }) {
  if (trend === "up") return <ArrowUp size={13} className="text-accent" />;
  if (trend === "down") return <ArrowDown size={13} className="text-red-400" />;
  return <Minus size={13} className="text-muted" />;
}

export default function PerformanceComparisonTable({ comparison, elapsedMinutes }) {
  if (!comparison) return null;

  return (
    <div className="bg-panel border border-border rounded-xl p-5">
      <div className="text-sm font-medium text-slate-200 mb-3">COMPARATIVO DE DESEMPENHO</div>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-muted text-xs">
            <th className="text-left font-normal pb-2"></th>
            <th className="text-right font-normal pb-2">Média dos últimos {comparison.sample_size} jogos</th>
            <th className="text-right font-normal pb-2">No jogo atual (até {elapsedMinutes}')</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {comparison.metrics.map((m) => (
            <tr key={m.label}>
              <td className="py-2 text-slate-300">{m.label}</td>
              <td className="py-2 text-right text-slate-200">
                {m.home_avg_last.toFixed(1)} <span className="text-muted">/</span> {m.away_avg_last.toFixed(1)}
              </td>
              <td className="py-2 text-right">
                <span className="inline-flex items-center gap-1 text-slate-100">
                  {m.home_current}
                  <TrendIcon trend={m.home_trend} />
                </span>
                <span className="text-muted mx-1">/</span>
                <span className="inline-flex items-center gap-1 text-slate-100">
                  {m.away_current}
                  <TrendIcon trend={m.away_trend} />
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="w-full mt-4 bg-accentdim text-accent text-sm font-medium py-2 rounded-lg hover:brightness-110">
        VER ANÁLISE COMPLETA
      </button>
    </div>
  );
}
