import {
  LayoutDashboard,
  Radio,
  Zap,
  ClipboardList,
  LineChart,
  Users,
  Settings,
  Crown,
} from "lucide-react";

const NAV_ITEMS = [
  { label: "Dashboard", icon: LayoutDashboard, active: true },
  { label: "Partidas Ao Vivo", icon: Radio },
  { label: "Recomendações", icon: Zap },
  { label: "Histórico de Apostas", icon: ClipboardList },
  { label: "Análises", icon: LineChart },
  { label: "Times", icon: Users },
  { label: "Configurações", icon: Settings },
];

export default function Sidebar({ leagues, selectedLeague, onLeagueChange, onlyValueBets, onToggleValueBets }) {
  return (
    <aside className="w-64 shrink-0 bg-panel border-r border-border flex flex-col h-full">
      <div className="px-5 py-5 flex items-center gap-2 border-b border-border">
        <div className="w-9 h-9 rounded-lg bg-accentdim flex items-center justify-center">
          <LineChart size={18} className="text-accent" />
        </div>
        <div>
          <div className="font-semibold text-slate-100 leading-tight">BetAnalyzer</div>
          <div className="text-[10px] tracking-widest text-muted">IN-PLAY ANALYTICS</div>
        </div>
      </div>

      <nav className="flex-1 py-4 px-3 space-y-1">
        {NAV_ITEMS.map(({ label, icon: Icon, active }) => (
          <button
            key={label}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
              active
                ? "bg-accentdim text-accent font-medium"
                : "text-muted hover:bg-panel2 hover:text-slate-200"
            }`}
          >
            <Icon size={17} />
            {label}
          </button>
        ))}
      </nav>

      <div className="px-4 pb-4 space-y-4 border-t border-border pt-4">
        <div className="text-xs font-semibold text-muted tracking-wide">FILTROS</div>
        <div>
          <label className="block text-xs text-muted mb-1">Ligas</label>
          <select
            value={selectedLeague}
            onChange={(e) => onLeagueChange(e.target.value)}
            className="w-full bg-panel2 border border-border rounded-md text-sm px-2 py-1.5 text-slate-200"
          >
            <option value="Todas">Todas</option>
            {leagues.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted">Apenas Value Bets</span>
          <button
            onClick={onToggleValueBets}
            className={`w-10 h-5 rounded-full relative transition-colors ${
              onlyValueBets ? "bg-accent" : "bg-panel2 border border-border"
            }`}
          >
            <span
              className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${
                onlyValueBets ? "left-5" : "left-0.5"
              }`}
            />
          </button>
        </div>
      </div>

      <div className="px-4 py-4 border-t border-border flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-accentdim text-accent flex items-center justify-center font-semibold">
          {"A"}
        </div>
        <div>
          <div className="text-sm text-slate-200 leading-tight">Analista Pro</div>
          <div className="text-[11px] text-accent flex items-center gap-1">
            Plano Premium <Crown size={11} />
          </div>
        </div>
      </div>
    </aside>
  );
}
