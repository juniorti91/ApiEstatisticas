import { Bell, RefreshCw } from "lucide-react";

export default function Header({ lastUpdate, onRefresh, refreshing }) {
  return (
    <header className="flex items-center justify-between px-6 py-5 border-b border-border">
      <div>
        <h1 className="text-xl font-semibold text-slate-100 tracking-tight">DASHBOARD</h1>
        <p className="text-sm text-muted">Visão geral e recomendações em tempo real</p>
      </div>
      <div className="flex items-center gap-4">
        <button className="relative text-muted hover:text-slate-200">
          <Bell size={19} />
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-accent" />
        </button>
        <span className="text-xs text-muted">
          Última atualização: {lastUpdate}
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent ml-1.5 align-middle" />
        </span>
        <button
          onClick={onRefresh}
          disabled={refreshing}
          className="flex items-center gap-2 bg-accent text-black text-sm font-medium px-4 py-2 rounded-lg hover:brightness-110 disabled:opacity-60"
        >
          <RefreshCw size={15} className={refreshing ? "animate-spin" : ""} />
          ATUALIZAR
        </button>
      </div>
    </header>
  );
}
