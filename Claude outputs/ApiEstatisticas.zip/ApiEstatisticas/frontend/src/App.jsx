import { useState } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";

export default function App() {
  const [selectedLeague, setSelectedLeague] = useState("Todas");
  const [onlyValueBets, setOnlyValueBets] = useState(false);

  return (
    <div className="flex h-screen bg-base">
      <Sidebar
        leagues={["Premier League", "La Liga", "Serie A", "Bundesliga", "Ligue 1", "Brasileirão"]}
        selectedLeague={selectedLeague}
        onLeagueChange={setSelectedLeague}
        onlyValueBets={onlyValueBets}
        onToggleValueBets={() => setOnlyValueBets((v) => !v)}
      />
      <Dashboard onlyValueBets={onlyValueBets} selectedLeague={selectedLeague} />
    </div>
  );
}
