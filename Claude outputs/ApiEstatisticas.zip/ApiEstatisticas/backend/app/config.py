"""
Configuracoes centrais da aplicacao.

Le valores do arquivo .env uma unica vez e expoe um objeto `settings`
singleton, evitando leitura repetida de variaveis de ambiente em todo o
codigo (organizacao + performance).
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    api_football_key: str = ""
    api_football_base_url: str = "https://v3.football.api-sports.io"

    database_url: str = "sqlite+aiosqlite:///./betanalyzer.db"

    collector_interval_minutes: int = 5
    live_scan_interval_minutes: int = 2
    monitored_league_ids: str = "39,140,135,78,61,71"

    frontend_origin: str = "http://localhost:5173"

    @property
    def monitored_league_id_list(self) -> list[int]:
        return [int(x) for x in self.monitored_league_ids.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
