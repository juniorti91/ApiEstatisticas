"""
Coletor de dados das partidas ao vivo.

Dois ritmos, por performance:
  * `scan_live_fixtures`  - roda com mais frequencia (padrao 2 min) e e
    barato: so lista partidas ao vivo nas ligas monitoradas e
    cria/atualiza os registros de Fixture. E o que decide QUAIS partidas
    entram em observacao.
  * `collect_snapshots`   - roda a cada 5 minutos (o requisito principal)
    e busca as estatisticas detalhadas (escanteios, chutes, posse...) de
    cada partida ja em observacao, gravando um MatchSnapshot por partida.

Ambos sao chamados pelo scheduler (app/services/scheduler.py).
"""
from __future__ import annotations

import logging
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.fixture import Fixture
from app.models.league import League
from app.models.snapshot import MatchSnapshot
from app.models.team import Team
from app.services.api_football_client import ApiFootballError, api_football_client
from app.services.stats_mapper import parse_fixture_statistics

logger = logging.getLogger("betanalyzer.collector")

FINISHED_STATUSES = {"FT", "AET", "PEN"}
LIVE_STATUSES = {"1H", "2H", "HT", "ET", "BT", "P", "LIVE"}


async def _get_or_create_league(session: AsyncSession, raw_league: dict) -> League:
    api_id = raw_league["id"]
    result = await session.execute(select(League).where(League.api_id == api_id))
    league = result.scalar_one_or_none()
    if league is None:
        league = League(
            api_id=api_id,
            name=raw_league.get("name", ""),
            country=raw_league.get("country", ""),
            logo_url=raw_league.get("logo", ""),
            season=raw_league.get("season", 0),
        )
        session.add(league)
        await session.flush()
    return league


async def _get_or_create_team(session: AsyncSession, raw_team: dict) -> Team:
    api_id = raw_team["id"]
    result = await session.execute(select(Team).where(Team.api_id == api_id))
    team = result.scalar_one_or_none()
    if team is None:
        team = Team(api_id=api_id, name=raw_team.get("name", ""), logo_url=raw_team.get("logo", ""))
        session.add(team)
        await session.flush()
    return team


async def _upsert_fixture(session: AsyncSession, raw_fixture: dict) -> Fixture:
    fx = raw_fixture["fixture"]
    league_data = raw_fixture["league"]
    teams_data = raw_fixture["teams"]
    goals_data = raw_fixture.get("goals", {})

    league = await _get_or_create_league(session, league_data)
    home_team = await _get_or_create_team(session, teams_data["home"])
    away_team = await _get_or_create_team(session, teams_data["away"])

    result = await session.execute(
        select(Fixture).where(Fixture.api_fixture_id == fx["id"])
    )
    fixture = result.scalar_one_or_none()
    status_short = fx.get("status", {}).get("short", "NS")
    elapsed = fx.get("status", {}).get("elapsed") or 0

    if fixture is None:
        fixture = Fixture(
            api_fixture_id=fx["id"],
            league_id=league.id,
            home_team_id=home_team.id,
            away_team_id=away_team.id,
            round=league_data.get("round", ""),
            kickoff_at=datetime.fromisoformat(fx["date"].replace("Z", "+00:00")).replace(tzinfo=None),
            status=status_short,
            elapsed_minutes=elapsed,
            goals_home=goals_data.get("home") or 0,
            goals_away=goals_data.get("away") or 0,
            is_monitored=status_short in LIVE_STATUSES,
        )
        session.add(fixture)
        await session.flush()
    else:
        fixture.status = status_short
        fixture.elapsed_minutes = elapsed
        fixture.goals_home = goals_data.get("home") or 0
        fixture.goals_away = goals_data.get("away") or 0
        if status_short in LIVE_STATUSES:
            fixture.is_monitored = True

    return fixture


async def scan_live_fixtures(session: AsyncSession) -> list[Fixture]:
    """Descobre partidas ao vivo nas ligas monitoradas e as coloca em observacao."""
    try:
        raw_fixtures = await api_football_client.live_fixtures(settings.monitored_league_id_list)
    except ApiFootballError as exc:
        logger.warning("Falha ao escanear partidas ao vivo: %s", exc)
        return []

    tracked: list[Fixture] = []
    for raw in raw_fixtures:
        fixture = await _upsert_fixture(session, raw)
        tracked.append(fixture)

    await session.commit()
    logger.info("Scan concluido: %d partida(s) ao vivo em observacao.", len(tracked))
    return tracked


async def track_fixture_by_id(session: AsyncSession, api_fixture_id: int) -> Fixture | None:
    """Adiciona manualmente uma partida especifica a observacao, mesmo que
    fora das ligas monitoradas automaticamente (usado pelo endpoint
    POST /api/matches/track)."""
    try:
        raw_fixture = await api_football_client.fixture_by_id(api_fixture_id)
    except ApiFootballError as exc:
        logger.warning("Falha ao buscar partida %s para monitoramento manual: %s", api_fixture_id, exc)
        return None
    if raw_fixture is None:
        return None

    fixture = await _upsert_fixture(session, raw_fixture)
    fixture.is_monitored = True
    await session.commit()
    await session.refresh(fixture)
    return fixture


async def collect_snapshots(session: AsyncSession) -> int:
    """
    Para cada partida em observacao e efetivamente ao vivo, busca as
    estatisticas atuais na API e grava um MatchSnapshot. Retorna quantos
    snapshots foram criados.
    """
    result = await session.execute(
        select(Fixture).where(Fixture.is_monitored.is_(True))
    )
    fixtures = list(result.scalars().all())
    created = 0

    for fixture in fixtures:
        # Atualiza o status/minuto mais recente antes de decidir o que fazer
        try:
            raw_fixture = await api_football_client.fixture_by_id(fixture.api_fixture_id)
        except ApiFootballError as exc:
            logger.warning("Falha ao atualizar partida %s: %s", fixture.api_fixture_id, exc)
            continue

        if raw_fixture is None:
            continue

        status_short = raw_fixture["fixture"]["status"]["short"]
        elapsed = raw_fixture["fixture"]["status"].get("elapsed") or fixture.elapsed_minutes
        fixture.status = status_short
        fixture.elapsed_minutes = elapsed
        fixture.goals_home = raw_fixture.get("goals", {}).get("home") or 0
        fixture.goals_away = raw_fixture.get("goals", {}).get("away") or 0

        if status_short in FINISHED_STATUSES:
            # Nao coleta snapshot de jogo encerrado; o results_tracker cuida dele.
            continue
        if status_short not in LIVE_STATUSES:
            continue

        try:
            raw_stats = await api_football_client.fixture_statistics(fixture.api_fixture_id)
        except ApiFootballError as exc:
            logger.warning("Falha ao buscar estatisticas da partida %s: %s", fixture.api_fixture_id, exc)
            continue

        home_team = await session.get(Team, fixture.home_team_id)
        away_team = await session.get(Team, fixture.away_team_id)
        parsed = parse_fixture_statistics(raw_stats, home_team.api_id, away_team.api_id)

        snapshot = MatchSnapshot(
            fixture_id=fixture.id,
            captured_at=datetime.utcnow(),
            minute=elapsed,
            goals_home=fixture.goals_home,
            goals_away=fixture.goals_away,
            **parsed,
        )
        session.add(snapshot)
        created += 1

    await session.commit()
    logger.info("Coleta concluida: %d snapshot(s) gravado(s).", created)
    return created
